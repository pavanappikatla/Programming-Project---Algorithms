public class TDR implements Cloneable{
    public String comb = "";
    public int profit = 0;
    public int sellDay = 0;
    public Object clone() throws CloneNotSupportedException
    {
        return super.clone();
    }
}
